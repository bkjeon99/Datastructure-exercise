#include <stdlib.h> // malloc, atoi
#include <stdio.h>
#include <ctype.h> // isdigit
#include <assert.h> // assert

#define MAX_STACK_SIZE	50

////////////////////////////////////////////////////////////////////////////////
// LIST type definition
typedef struct node
{
	char		data;
	struct node	*left;
	struct node	*right;
} NODE;

typedef struct
{
	NODE	*root;
} TREE;

////////////////////////////////////////////////////////////////////////////////
// Prototype declarations

/* Allocates dynamic memory for a tree head node and returns its address to caller
return	head node pointer
NULL if overflow
*/
TREE *createTree(void)
{
	TREE * tree = (TREE *)malloc(sizeof(TREE));
	return tree;
};

/* Deletes all data in tree and recycles memory
return	NULL head pointer
*/
TREE *destroyTree(TREE *pTree);

static void _destroy(NODE *root)
{
	if (root->left != NULL)
	{
		_destroy(root->left);
	}
	if (root->right != NULL)
	{
		_destroy(root->right);
	}
	free(root);
	return;
};

/*  Allocates dynamic memory for a node and returns its address to caller
return	node pointer
NULL if overflow
*/
static NODE *_makeNode(char ch)
{
	NODE * node = (NODE *)malloc(sizeof(NODE));
	node->data = ch;
	node->left = NULL;
	node->right = NULL;
	return node;
};

/* converts postfix expression to binary tree
return	1 success
0 invalid postfix expression
*/
int postfix2tree(char *expr, TREE *pTree)
{
	NODE * symbol[511] = { NULL };
	int i = 0, root = 1;
	int stack_pop = 0;
	NODE * temp = NULL;

	while (expr[i] != NULL)
	{
		i = i + 1;
	}
	i = i - 1;

	if (48 <= expr[i] && expr[i] <= 57)
	{
		if (i == 0)
		{
			pTree->root = _makeNode(expr[i]);
			return 1;
		}
		else
		{
			free(pTree);
			return 0;
		}
	}

	while (i >= 0)
	{
		if (48 <= expr[i] && expr[i] <= 57)
		{
			if (stack_pop == 0)
			{
				_destroy(pTree->root);
				free(pTree);
				return 0;
			}
			temp = _makeNode(expr[i]);
			if (symbol[stack_pop - 1]->right == NULL) symbol[stack_pop - 1]->right = temp;
			else if (symbol[stack_pop - 1]->left == NULL)
			{
				symbol[stack_pop - 1]->left = temp;
				symbol[stack_pop - 1] = NULL;
				stack_pop--;
			}
			printf("%d", stack_pop);

		}

		else if (expr[i] == '*' || expr[i] == '+' || expr[i] == '-' || expr[i] == '/')
		{
			symbol[stack_pop] = _makeNode(expr[i]);
			if (root == 1)
			{
				pTree->root = symbol[stack_pop];
				stack_pop = 1;
				root = 0;
			}
			else if(stack_pop == 0)
			{
				_destroy(pTree->root);
				free(symbol[stack_pop]);
				free(pTree);

				return 0;
			}
			else
			{
				if (symbol[stack_pop - 1]->right == NULL) symbol[stack_pop - 1]->right = symbol[stack_pop];
				else if (symbol[stack_pop - 1]->left == NULL)
				{
					symbol[stack_pop - 1]->left = symbol[stack_pop];
					symbol[stack_pop - 1] = symbol[stack_pop];
					symbol[stack_pop] = NULL;
					stack_pop--;
				}
				stack_pop++;
			}
		}
		else return 0;

		i--;
	}
	if (stack_pop != 0)
	{
		_destroy(pTree->root);
		while (stack_pop > 0)
		{
			free(symbol[stack_pop-1]);
			stack_pop--;
		}
		free(pTree);

		return 0;
	}


	return 1;
};

/* Print node in tree using inorder traversal
*/
void traverseTree(TREE *pTree);

/* internal traversal function
an implementation of ALGORITHM 6-6
*/
static void _traverse(NODE *root)
{
	if (root != NULL)
	{
		if (48 <= root->data && root->data <= 57)
		{
			printf("%c", root->data);
			return;
		}
		else
		{
			printf("(");
			_traverse(root->left);
			printf("%c", root->data);
			_traverse(root->right);
			printf(")");
			return;
		}
	}
	return;
};

/* Print tree using inorder right-to-left traversal
*/
void printTree(TREE *pTree);

/* internal traversal function
*/
static void _infix_print(NODE *root, int level)
{
	int i;
	if (root != NULL)
	{
		_infix_print(root->right, level + 1);
		for (i = 0; i < level; i++)
		{
			printf("	");
		}
		printf("%c \n", root->data);
		_infix_print(root->left, level + 1);
		return;
	}
	return;
};

/* evaluate postfix expression
return	value of expression
*/
float evalPostfix(char *expr)
{
	float number[513];
	int i = 0, stack_pop = 0;
	while (expr[i] != NULL)
	{
		if (48 <= expr[i] && expr[i] <= 57)
		{
			number[stack_pop] = (float)expr[i] - 48;
			stack_pop++;
		}
		else
		{
			switch (expr[i])
			{
			case '+':
				number[stack_pop - 2] = number[stack_pop - 1] + number[stack_pop - 2];
				break;
			case '-':
				number[stack_pop - 2] = number[stack_pop - 1] - number[stack_pop - 2];
				break;
			case '*':
				number[stack_pop - 2] = number[stack_pop - 1] * number[stack_pop - 2];
				break;
			case '/':
				number[stack_pop - 2] = number[stack_pop - 1] / number[stack_pop - 2];
				break;
			}
			stack_pop--;
		}
		i++;
	}
	return number[0];
};

////////////////////////////////////////////////////////////////////////////////
TREE *destroyTree(TREE *pTree)
{
	if (pTree)
	{
		_destroy(pTree->root);
	}

	free(pTree);

	return NULL;
}

////////////////////////////////////////////////////////////////////////////////
void printTree(TREE *pTree)
{
	_infix_print(pTree->root, 0);

	return;
}

////////////////////////////////////////////////////////////////////////////////
void traverseTree(TREE *pTree)
{
	_traverse(pTree->root);

	return;
}

////////////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
	TREE *tree;
	char expr[1024];

	fprintf(stdout, "\nInput an expression (postfix): ");

	while (fscanf(stdin, "%s", expr) == 1)
	{
		// creates a null tree
		tree = createTree();

		if (!tree)
		{
			printf("Cannot create tree\n");
			return 100;
		}

		// postfix expression -> expression tree
		int ret = postfix2tree(expr, tree);
		if (!ret)
		{
			fprintf(stdout, "invalid expression!\n");
			continue;
		}

		// expression tree -> infix expression
		fprintf(stdout, "\nInfix expression : ");
		traverseTree(tree);

		// print tree with right-to-left infix traversal
		fprintf(stdout, "\n\nTree representation:\n");
		printTree(tree);

		// evaluate postfix expression
		float val = evalPostfix(expr);
		fprintf(stdout, "\nValue = %f\n", val);

		// destroy tree
		destroyTree(tree);

		fprintf(stdout, "\nInput an expression (postfix): ");
	}
	return 0;
}